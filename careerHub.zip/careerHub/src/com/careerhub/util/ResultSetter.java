package com.careerhub.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.careerhub.entity.Applicant;

public class ResultSetter {
public static Applicant applicant(ResultSet resultset) throws SQLException
{
	Applicant ap= new Applicant();
	
	ap.setApplicantID(resultset.getInt("ApplicantId"));
	ap.setFirstName(resultset.getString("FirstName"));
	ap.setLastName(resultset.getString("LastName"));
	ap.setEmail(resultset.getString("Email"));
	ap.setPhone(resultset.getString("Phone"));
	ap.setResume(resultset.getString("Resume"));
	
	return ap;
}
}
