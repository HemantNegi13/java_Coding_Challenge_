package com.careerhub.Service;

import java.util.List;

public interface IjobListing {

	void apply();
    
	void getApplicant();
}
