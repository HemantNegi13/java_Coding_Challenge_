package com.careerhub.Service;
import com.careerhub.dao.*;
import com.careerhub.entity.*;
public class CompanyService implements ICompany {
    
	CompanyDao obj= new CompanyDao();
	@Override
	public void postJob(Joblisting jb) {
		
      obj.postJob(jb);
	}

	@Override
	public void getJobs() {
		// TODO Auto-generated method stub

	}

}
