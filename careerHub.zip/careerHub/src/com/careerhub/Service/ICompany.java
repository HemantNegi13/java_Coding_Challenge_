package com.careerhub.Service;

import java.util.List;

import com.careerhub.entity.Joblisting;

public interface ICompany {
	 void getJobs();
	 
	void postJob(Joblisting jb);
}
