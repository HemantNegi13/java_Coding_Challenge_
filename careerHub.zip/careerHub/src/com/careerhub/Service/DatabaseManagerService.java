package com.careerhub.Service;

import com.careerhub.dao.DatabaseManagerDao;
import com.careerhub.entity.Applicant;
import com.careerhub.entity.Company;
import com.careerhub.entity.JobApplication;
import com.careerhub.entity.Joblisting;

public class DatabaseManagerService implements IdatabaseManager {
DatabaseManagerDao dbmd=new DatabaseManagerDao();
	@Override
	public void initializeDatabase() {
		// TODO Auto-generated method stub

	}

	@Override
	public void insertJobListing(Joblisting job) {
		// TODO Auto-generated method stub

	}

	@Override
	public void insertCompany(Company company) {
		// TODO Auto-generated method stub

	}

	@Override
	public void insertApplicant(Applicant applicant) {
		// TODO Auto-generated method stub

	}

	@Override
	public void insertJobApplication(JobApplication application) {
		try {
		dbmd.insertJobApplication(application);
		}catch(Exception e)
		{
			e.getMessage();
		}
	}

	@Override
	public void getJobListings() {
		// TODO Auto-generated method stub

	}

	@Override
	public void getCompanies() {
		// TODO Auto-generated method stub

	}

	@Override
	public void getApplicants() {
		// TODO Auto-generated method stub

	}

	@Override
	public void getApplicationsForJob(int jobID) {
		// TODO Auto-generated method stub

	}

}
