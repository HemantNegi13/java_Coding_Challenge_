package com.careerhub.Service;

import com.careerhub.entity.*;
import com.careerhub.dao.*;

public class ApplicantService implements IApplicant {
	ApplicantDao obj1=new ApplicantDao();

    @Override
	public void CreateProfile(Applicant profile) {
		
			try{
				obj1.createProfile(profile);
			}catch(Exception e){
				e.getMessage();
			}
	}

	@Override
	public void Applyforjob(int jobid, String coverletter) {
		
			obj1.applyForJob(jobid,coverletter);
			
		

	}

}
