package com.careerhub.Service;

import com.careerhub.entity.Applicant;

public interface IApplicant {

	void Applyforjob(int jobid,String coverletter);
	void CreateProfile(Applicant profile);
}
