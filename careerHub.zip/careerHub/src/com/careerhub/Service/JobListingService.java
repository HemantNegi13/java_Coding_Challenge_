package com.careerhub.Service;

import java.util.ArrayList;
import java.util.List;

import com.careerhub.dao.JoblistingDao;
import com.careerhub.entity.Applicant;
import com.careerhub.entity.JobApplication;

public class JobListingService implements IjobListing {

	JoblistingDao jbl=new JoblistingDao();
	@Override
	public void apply() {
		// TODO Auto-generated method stu

	}

	@Override
	public void getApplicant() {
		List<Applicant> arr= jbl.getApplicants();
		for(Applicant ap:arr)
		{
			System.out.println(ap.toString());
		}

	}

}
