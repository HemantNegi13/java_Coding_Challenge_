package com.careerhub.entity;
import java.time.LocalDate;
import java.util.*;
public class Joblisting {
	    private int jobID;
	    private Company company;
	    private String jobTitle;
	    private String jobDescription;
	    private String jobLocation;
	    private float salary;
	    private String jobType;
	    private LocalDate postedDate;
	    
		public int getJobID() {
			return jobID;
		}
		public void setJobID(int jobID) {
			this.jobID = jobID;
		}
		public Company getCompany() {
			return company;
		}
		public String getJobTitle() {
			return jobTitle;
		}
		public void setJobTitle(String jobTitle) {
			this.jobTitle = jobTitle;
		}
		public String getJobDescription() {
			return jobDescription;
		}
		public void setJobDescription(String jobDescription) {
			this.jobDescription = jobDescription;
		}
		public String getJobLocation() {
			return jobLocation;
		}
		public void setJobLocation(String jobLocation) {
			this.jobLocation = jobLocation;
		}
		public float getSalary() {
			return salary;
		}
		public void setSalary(float salary) {
			this.salary = salary;
		}
		public String getJobType() {
			return jobType;
		}
		public void setJobType(String jobType) {
			this.jobType = jobType;
		}
		public LocalDate getPostedDate() {
			return postedDate;
		}
		public void setPostedDate(LocalDate postedDate) {
			this.postedDate = postedDate;
		}
		
		public Joblisting(Company company, String jobTitle, String jobDescription, String jobLocation,
				float salary, String jobType, LocalDate postedDate) {
			super();
			this.company = company;
			this.jobTitle = jobTitle;
			this.jobDescription = jobDescription;
			this.jobLocation = jobLocation;
			this.salary = salary;
			this.jobType = jobType;
			this.postedDate = postedDate;
		}
		public Joblisting() {
			super();
		}
		
		@Override
		public String toString() {
			return "JobListing [jobID=" + jobID + ", companyID=" + company.getCompanyID() + ", jobTitle=" + jobTitle
					+ ", jobDescription=" + jobDescription + ", jobLocation=" + jobLocation + ", salary=" + salary
					+ ", jobType=" + jobType + ", postedDate=" + postedDate + "]";
		}
		public void setCompany(Company company) {
			this.company = company;
		}

	}

