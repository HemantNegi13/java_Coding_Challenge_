package com.careerhub.dao;

import com.careerhub.entity.Applicant;
import com.careerhub.exception.*;
public interface IApplicantDao {
	

    void applyForJob(int jobID, String coverLetter)throws ApplicationDeadlineException;

	void createProfile(Applicant profile)throws InvalidEmailFormatException;
}
