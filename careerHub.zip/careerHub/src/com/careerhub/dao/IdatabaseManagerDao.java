package com.careerhub.dao;

import java.util.List;
import com.careerhub.entity.*;
import com.careerhub.exception.FileUploadException;

public interface IdatabaseManagerDao {

	    void initializeDatabase();

	    void insertJobListing(Joblisting job);

	    void insertCompany(Company company);

	    void insertApplicant(Applicant applicant);

	    void insertJobApplication(JobApplication application)throws FileUploadException;

	    List<Joblisting> getJobListings();

	    List<Company> getCompanies();

	    List<Applicant> getApplicants();

	    List<JobApplication> getApplicationsForJob(int jobID);

}
