package com.careerhub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.careerhub.entity.Applicant;
import com.careerhub.util.DBUtil;
import com.careerhub.util.ResultSetter;

public class JoblistingDao implements IjobListingDao {
	PreparedStatement preparedStatement;
	Statement statement;
	ResultSet resultSet;
	@Override
	public void apply(int applicantID, String coverLetter) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Applicant> getApplicants(){
		List<Applicant> arr= new ArrayList<>();
		try {
			Connection connection = DBUtil.createConnection();
		preparedStatement = connection.prepareStatement("Select * From Applicant");
		resultSet = preparedStatement.executeQuery();
		while(resultSet.next()) {
			arr.add(ResultSetter.applicant(resultSet));
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
		
	DBUtil.closeConnection();
	return arr;
	}

}
