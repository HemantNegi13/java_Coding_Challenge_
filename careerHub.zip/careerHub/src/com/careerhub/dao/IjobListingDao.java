package com.careerhub.dao;

import java.sql.SQLException;
import java.util.List;
import com.careerhub.entity.*;

public interface IjobListingDao {
	void apply(int applicantID, String coverLetter);

    List<Applicant> getApplicants();
}
