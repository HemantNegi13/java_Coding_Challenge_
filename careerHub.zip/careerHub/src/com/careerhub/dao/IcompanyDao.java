package com.careerhub.dao;

import java.util.List;
import com.careerhub.entity.*;

public interface IcompanyDao {
	   List<Joblisting> getJobs();

	void postJob(Joblisting jb);
}
