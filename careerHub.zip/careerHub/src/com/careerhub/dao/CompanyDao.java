package com.careerhub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.sql.Date;

import com.careerhub.entity.Joblisting;
import com.careerhub.util.DBUtil;

public class CompanyDao implements IcompanyDao {

	PreparedStatement preparedStatement;
	Statement statement;
	ResultSet resultSet;

	@Override
	public void postJob(Joblisting jb) {
		try {
			Connection connection = DBUtil.createConnection();
			
			preparedStatement = connection.prepareStatement("INSERT INTO JobListing(CompanyID,JobTitle,JobDescription,JobLocation,Salary,JobType,PostedDate) VALUES (?,?,?,?,?,?,?)");
			preparedStatement.setInt(1,jb.getCompany().getCompanyID());
			preparedStatement.setString(2,jb.getJobTitle());
			preparedStatement.setString(3,jb.getJobDescription());
			preparedStatement.setString(4,jb.getJobLocation());
			preparedStatement.setFloat(5,jb.getSalary());
			preparedStatement.setString(6,jb.getJobType());
			preparedStatement.setDate(7,Date.valueOf(jb.getPostedDate()));

			int row= preparedStatement.executeUpdate();
			if(row==1)
			{
				System.out.println("Done Done");
			}
			else {
				System.out.println("Not Done");
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
      DBUtil.closeConnection();
	}

	@Override
	public List<Joblisting> getJobs() {
		// TODO Auto-generated method stub
		return null;
	}

}
