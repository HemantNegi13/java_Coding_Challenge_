package com.careerhub.main;

import java.sql.Connection;
import java.util.Scanner;
import com.careerhub.util.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;

import com.careerhub.util.DBUtil;
import com.careerhub.dao.*;
import com.careerhub.entity.*;
import com.careerhub.exception.*;
import com.careerhub.Service.*;

public class MainModule {
	 static ApplicantService apsrvc=new ApplicantService();
	static CompanyService cpsrvc=new CompanyService();
	static JobListingService jbsrvc=new JobListingService();
	static DatabaseManagerService dbsrvc=new DatabaseManagerService();
	public static void main(String[] args) {
		int choice = -1;
		Scanner sc = new Scanner(System.in);
		while (choice != 0) {
			System.out.println("1. Applicant");
			System.out.println("2. Company");
			System.out.println("3. Job Application");
			System.out.println("4. Job Listing");
			System.out.println("5. Database Manager");
			System.out.println("0. Exit");
			System.out.println("Plese Enter your choice");

			choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
			case 1:
				ApplicantView();
				break;
			case 2:
				CompanyView();
				break;
			case 3:
				JobApplicationView();
				break;
			case 4:
				JoblistingView();
				break;
			case 5:
				DatabaseManagerView();
				break;
			case 0:
				System.out.println("You are out of careerhub");
				break;
			default:
				System.out.println("Invalid choice. Please try again.");
				break;
            }
	}
 
}

	private static void DatabaseManagerView() {
		int choice = -1;
		Scanner sc = new Scanner(System.in);
		while (choice != 0) {
			System.out.println("1.Initialise Database");
			System.out.println("2. Insert Job Listing");
			System.out.println("3. Insert Company");
			System.out.println("4. Insert Job Application");
			System.out.println("5. Insert Applicant");
			System.out.println("0.Exit");
		   choice=sc.nextInt();
		   sc.nextLine();
		   switch (choice) {
		   case 0:
			   System.out.println("You exited the Database Manager");
			   break;
		   case 1:
			   System.out.println("Method yet to impliment");
			   break;
		   case 2:
			   System.out.println("Method yet to impliment");
			   break;
		   case 3:
			   System.out.println("Method yet to impliment");
			   break;
		   case 4:
			   System.out.println("Insert the data for job application");
			   JobApplication jbap= new JobApplication();
			   
			   System.out.println("Enter the Application Id");
			   jbap.setApplicantID(sc.nextInt());
			   sc.nextLine();
			   
			   System.out.println("Enter the Job Id");
			   jbap.setJobID(sc.nextInt());
			   sc.nextLine();
			   
			   System.out.println("Enter the Applicant Id");
			   jbap.setApplicantID(sc.nextInt());
			   sc.nextLine();
			   
			   System.out.println("Enter the Application Date");
			   System.out.println("Enter the Application year");
			   int year=sc.nextInt();
			   sc.nextLine();
			   System.out.println("Enter the Application month");
			   int month=sc.nextInt();
			   sc.nextLine();
			   System.out.println("Enter the Application date");
			   int date=sc.nextInt();
			   sc.nextLine();
			   jbap.setApplicationDate(LocalDate.of(year, month, date));
			   
			   System.out.println("Enter the Cover Letter");
			   jbap.setCoverLetter(sc.nextLine());
			   
			   dbsrvc.insertJobApplication(jbap);
			   break;
		   default:
				System.out.println("Invalid choice. Please try again.");
				break;
		   }
		   }
		
	}

	
	private static void JoblistingView() {
		int choice = -1;
		Scanner sc = new Scanner(System.in);
		while (choice != 0) {
			System.out.println("1.Apply fro job");
			System.out.println("2. Get the applicant ");
			System.out.println("0.Exit");
		   choice=sc.nextInt();
		   sc.nextLine();
		   switch (choice) {
		   case 1:
			   System.out.println("Method yet to impliment");
			   break;
		   case 2:
			   System.out.println("All the applications are ");
			   jbsrvc.getApplicant();
			   break;
		   }
		}
		
	}

	private static void JobApplicationView() {
		// TODO Auto-generated method stub
		
	}

	private static  void CompanyView() {
		int choice = -1;
		Scanner sc = new Scanner(System.in);
		while (choice != 0) {
			System.out.println("1.Post Job");
			System.out.println("2. Get Job");
			System.out.println("0.Exit");
		   choice=sc.nextInt();
		   sc.nextLine();
		   switch (choice) {
			case 1:
				Company cmp=new Company();
				Joblisting jb =new Joblisting();
				System.out.println("Enter the Company Id");
				cmp.setCompanyID(sc.nextInt());
				sc.nextLine();
				jb.setCompany(cmp);
				System.out.println("Enter the Job Title");
				jb.setJobTitle(sc.nextLine());
				
				System.out.println("Enter the Job Description");
				jb.setJobDescription(sc.nextLine());
				
				System.out.println("Enter the Job Location");
				jb.setJobLocation(sc.nextLine());
				
				System.out.println("Enter the Salary");
				jb.setSalary(sc.nextFloat());
				sc.nextLine();
				
				System.out.println("Enter the Job Type");
				jb.setJobType(sc.nextLine());
				
				jb.setPostedDate(LocalDate.now());
				cpsrvc.postJob(jb);
				break;
			case 2:
				CompanyView();
				break;
			case 0:
				System.out.println("You are out of Applicant");
				break;
			default:
				System.out.println("Invalid choice. Please try again.");
				break;
			
		}
		
		
	}
		
	}

	private static void ApplicantView() {
		int choice = -1;
		Scanner sc = new Scanner(System.in);
		while (choice != 0) {
			System.out.println("1. Create Profile");
			System.out.println("2. ApplyForJob");
			System.out.println("0.Exit");
		   choice=sc.nextInt();
		   sc.nextLine();
		   switch (choice) {
			case 1:
				Applicant profile=new Applicant();
				System.out.println("Enter the firstname");
				profile.setFirstName(sc.nextLine());
				
				System.out.println("Enter the LastName");
				profile.setLastName(sc.nextLine());
				
				System.out.println("Enter the email");
				profile.setEmail(sc.nextLine());
				
				System.out.println("Enter the phone");
				profile.setPhone(sc.nextLine());
				
				apsrvc.CreateProfile(profile);
				break;
			case 2:
				CompanyView();
				break;
			case 0:
				System.out.println("You are out of Applicant");
				break;
			default:
				System.out.println("Invalid choice. Please try again.");
				break;
			
		}
		
		
	}

}
	}
